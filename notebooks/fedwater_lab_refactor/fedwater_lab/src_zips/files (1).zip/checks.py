"""One register, every check, with its verdict attached.

Each stage of the dependence workstream appends rows here instead of
printing. The point is that a claim at the end of the notebook can be traced
to the checks that were live when it was made: `Register.frame()` is a table
you can store next to the score rows, and `assert_all` is what stops a
notebook that has already failed from producing numbers.

A row is `(stage, check, value, passed, note)`. `passed` may be `None` for a
check that only reports (a census, a count) -- those never fail a run but do
appear in the register, because "this was measured and it was 8" is itself
the thing a later reader needs.

`honest_n` is a row kind rather than a check: independent worlds, seeds and
pairs behind whatever was just computed, recorded next to it so that a
p-value can never be read without its sample size in the same frame.
"""
from __future__ import annotations

import pandas as pd

__all__ = ["Register"]


class Register:
    """Append-only sanity register."""

    def __init__(self, label: str = ""):
        self.label = label
        self.rows: list[dict] = []

    # ------------------------------------------------------------- appending
    def add(self, stage: str, check: str, value, passed: bool | None = None,
            note: str = "") -> "Register":
        self.rows.append({"stage": str(stage), "check": str(check),
                          "value": value, "passed": passed, "note": note})
        return self

    def report(self, stage: str, check: str, value, note: str = "") -> "Register":
        """A measurement that cannot fail (a census, a count)."""
        return self.add(stage, check, value, None, note)

    def expect(self, stage: str, check: str, value, ok: bool,
               note: str = "") -> "Register":
        return self.add(stage, check, value, bool(ok), note)

    def honest_n(self, stage: str, worlds: int, seeds: int, pairs: int,
                 note: str = "") -> "Register":
        return self.report(stage, "honest n (worlds / seeds / pairs)",
                           f"{worlds} / {seeds} / {pairs}", note)

    def extend(self, other: "Register | pd.DataFrame", stage: str | None = None
               ) -> "Register":
        """Merge another register (or a frame of its rows) into this one."""
        rows = other.rows if isinstance(other, Register) else \
            other.to_dict("records")
        for r in rows:
            r = dict(r)
            if stage is not None:
                r["stage"] = stage
            self.rows.append(r)
        return self

    # -------------------------------------------------------------- reading
    def frame(self) -> pd.DataFrame:
        cols = ["stage", "check", "value", "passed", "note"]
        return pd.DataFrame(self.rows, columns=cols)

    def failed(self, stage: str | None = None) -> pd.DataFrame:
        f = self.frame()
        f = f[f["passed"] == False]                          # noqa: E712
        return f if stage is None else f[f["stage"] == stage]

    def assert_all(self, stage: str | None = None) -> None:
        bad = self.failed(stage)
        if len(bad):
            lines = "\n".join(f"  [{r.stage}] {r.check}: {r.value}"
                              + (f"  ({r.note})" if r.note else "")
                              for r in bad.itertuples())
            raise AssertionError(
                f"{len(bad)} sanity check(s) failed"
                + (f" in stage {stage}" if stage else "") + ":\n" + lines)

    def __len__(self) -> int:
        return len(self.rows)

    def __repr__(self) -> str:
        f = self.frame()
        n_fail = int((f["passed"] == False).sum())           # noqa: E712
        n_test = int(f["passed"].notna().sum())
        return (f"Register({self.label!r}, rows={len(f)}, "
                f"tests={n_test}, failed={n_fail})")
